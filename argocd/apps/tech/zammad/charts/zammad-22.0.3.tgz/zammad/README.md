# Zammad Helm Chart

A [Helm](https://helm.sh) chart to install [Zammad](https://zammad.org) on [Kubernetes](https://kubernetes.io)

## About Zammad

Are you juggling countless customer inquiries across multiple channels?
Struggling to keep your support team on the same page?
Or spending more time managing your helpdesk than delivering exceptional support to your customers?

Zammad is your Swiss Army knife - a web-based, open-source helpdesk and customer support platform
packed with features to streamline customer communication across channels like email, chat, telephone and social media.

### The Software

The Zammad software is and will stay open source. It is licensed under the GNU AGPLv3.
The source code is [available on GitHub](https://github.com/zammad/zammad) and owned by
the [Zammad Foundation](https://zammad-foundation.org/), which is independent of commercial
providers such as Zammad GmbH.

### The Company - Zammad GmbH

The development of Zammad is carried out by the [amazing team of people](https://zammad.com/en/company)
at [Zammad GmbH](https://zammad.com/) in collaboration with the community.
We love to create open source software for you. If you want to ensure the Zammad software
has a bright and sustainable future, consider becoming a Zammad customer!

> Are you tired of complex setup, configuration, backup and update tasks? Let us handle this stuff for you! 🚀
>
> The easiest and often most cost-effective way to operate Zammad is [our cloud service](https://zammad.com/en/pricing).
> Give it a try with a [free trial instance](https://zammad.com/en/getting-started)!

## Introduction

This chart will do the following:

- Install several `Deployment`s for the different Zammad services
- Install Elasticsearch, Memcached, PostgreSQL, Redis & RustFS (optional) as requirements

Be aware that the Zammad Helm chart version is different from the actual Zammad version.

## Prerequisites

- Kubernetes 1.21+
- Helm 3.8.0+
- Cluster with at least 4GB of free RAM
- The [ECK operator](https://www.elastic.co/guide/en/cloud-on-k8s/current/k8s-install-helm.html),
  **version 3.5.0 or newer**, must be installed in the cluster when using the bundled
  Elasticsearch (`zammadConfig.elasticsearch.enabled: true`, the default). The bundled
  Elasticsearch is deployed via the official `eck-elasticsearch` chart (pinned to `0.20.0`
  in `Chart.yaml`), which creates an `Elasticsearch` custom resource that is reconciled by
  the operator. If your cluster already runs an
  older ECK operator for other workloads, upgrade it first — an older operator's webhook may
  reject the `Elasticsearch` resource this chart creates. This is **not** required when
  connecting to an external Elasticsearch service.

  Install the operator once per cluster:

  ```console
  helm repo add elastic https://helm.elastic.co
  helm repo update
  helm install elastic-operator elastic/eck-operator --namespace elastic-system --create-namespace
  ```

## Installing the Chart

The chart is published as an OCI artifact on GitHub Container Registry. To install the chart use the following:

```console
helm upgrade --install zammad oci://ghcr.io/zammad/charts/zammad
```

The classic Helm repository at `https://zammad.github.io/zammad-helm` is no longer updated. Its last
chart version is 20.0.2. If you installed the chart from there, see
[Switching to the OCI Registry](#switching-to-the-oci-registry).

Database migration and seeding run in a separate init job. `--wait` does not wait for jobs, so add
`--wait --wait-for-jobs` if your tooling must not continue until Zammad is initialised.

Once the Zammad pod is ready, it can be accessed using the ingress or port forwarding.
To use port forwarding:

```console
kubectl port-forward service/zammad-nginx 8080
```

Now you can open <http://localhost:8080> in your browser.

## Uninstalling the Chart

To remove the chart again use the following:

```console
helm delete zammad
```

## Configuration

See [Customizing the Chart Before Installing](https://helm.sh/docs/intro/using_helm/#customizing-the-chart-before-installing).
To see all configurable options with detailed comments, visit the chart's [values.yaml](./values.yaml), or run this configuration command:

```console
helm show values oci://ghcr.io/zammad/charts/zammad
```

### Choosing the Storage Provider

Zammad uses the database as the default storage provider for new systems. This works well for the majority of systems.
Only if you have a large volume of tickets and attachments, you may need to store attachments in another storage provider.

We recommend the `S3` storage provider using the optional [`rustfs`](https://rustfs.com) subchart in this
case (`zammadConfig.rustfs.enabled: true`). RustFS is an S3-compatible object store; it replaced the
former `minio` subchart in chart version 19.0.0, see [Upgrading](#from-chart-version-18x-to-1900).

Unlike the former `minio` subchart, the `rustfs` chart does not create buckets on its own, and Zammad
never creates the bucket either - it only reads from it. The chart therefore provisions the bucket from
the `zammad-init` job. Set `zammadConfig.rustfs.bucketInitialisation: false` if you want to manage the
bucket yourself. This never touches an external S3 service, only the bundled instance.

You can also use `File` storage. In this case, you need to provide an existing `PVC` via `zammadConfig.storageVolume`.
Note that this `PVC` must provide `ReadWriteMany` access to work properly for the different Deployments which may be on different nodes.

#### How to migrate from `File` to `S3` storage

- In the admin panel, go to "System -> Storage" and select "Simple Storage (S3)" as the new storage provider.
- Migrate existing `File` store content by running `kubectl exec zammad-0 -c zammad-railsserver -- bundle exec rails r "Store::File.move('File', 'S3')"`. Example:

```log
kubectl exec zammad-0 -c zammad-railsserver -- bundle exec rails r "Store::File.move('File', 'S3')"
I, [2024-01-24T11:06:13.501572 #168]  INFO -- : ActionCable is using the redis instance at redis://:zammad@zammad-redis-master:6379.
I, [2024-01-24T11:06:13.506180#168-5980]  INFO -- : Using memcached as Rails cache store.
I, [2024-01-24T11:06:13.506246#168-5980]  INFO -- : Using the Redis back end for Zammad's web socket session store.
I, [2024-01-24T11:06:14.561169#168-5980]  INFO -- : storage remove '/opt/zammad/storage/fs/ab76/81d1/a4177/4c41f/12ddb67/96ee19e/a7e7c780a3227936c507cfbfe946afb9'
I, [2024-01-24T11:06:14.561654#168-5980]  INFO -- : Moved file ab7681d1a41774c41f12ddb6796ee19ea7e7c780a3227936c507cfbfe946afb9 from File to S3
I, [2024-01-24T11:06:14.566327#168-5980]  INFO -- : storage remove '/opt/zammad/storage/fs/dbaa/01dd/0df3a/33bce/e87c420/f221f59/6df9db38a402b30fccea09cc444a9fb0'
I, [2024-01-24T11:06:14.566513#168-5980]  INFO -- : Moved file dbaa01dd0df3a33bcee87c420f221f596df9db38a402b30fccea09cc444a9fb0 from File to S3
I, [2024-01-24T11:06:14.627896#168-5980]  INFO -- : storage remove '/opt/zammad/storage/fs/e81f/fb09/c5a26/f2081/f93401a/cbe8fff/9983e56c86fccb48d17a2eb1e5900b5b'
```

### Redis Sentinel

The chart can talk to Redis through Sentinel instead of a direct connection, either using the bundled Redis subchart or an external Redis/Sentinel setup.

To enable Sentinel with the **bundled** Redis subchart:

```yaml
redis:
  sentinel:
    enabled: true
  architecture: replication # required: the Sentinel service only exists in this mode

zammadConfig:
  redis:
    sentinel:
      enabled: true
```

When bundled Redis is enabled, `redis.sentinel.enabled` and `redis.architecture=replication` are both required whenever `zammadConfig.redis.sentinel.enabled` is set — the chart fails fast at render time otherwise. The Sentinel hostname is derived automatically from the release name; you don't need to set `zammadConfig.redis.sentinel.sentinels`.

To use an **external** Redis/Sentinel setup instead, disable the bundled subchart and point at your own Sentinels:

```yaml
zammadConfig:
  redis:
    enabled: false
    sentinel:
      enabled: true
      sentinels:
        - my-sentinel-1:26379
        - my-sentinel-2:26379
      masterName: mymaster
```

### Deploying on OpenShift

To deploy on OpenShift unprivileged and with [arbitrary UIDs and GIDs](https://cloud.redhat.com/blog/a-guide-to-openshift-and-uids):

- [Delete the default key](https://helm.sh/docs/chart_template_guide/values_files/#deleting-a-default-key) `securityContext` and `zammadConfig.initContainers.zammad.securityContext.runAsUser` with `null`.
- Disable if used:
  - also `podSecurityContext` in all subcharts.

The bundled Elasticsearch uses `node.store.allow_mmap: false` by default (see
`elasticsearch.nodeSets[].config`), so no privileged sysctl init container is
required. If you raise `vm.max_map_count` for production instead, do so on the
node level rather than via a privileged init container.

```yaml
securityContext: null

zammadConfig:
  initContainers:
    zammad:
      securityContext:
        runAsUser: null
    volumePermissions:
      enabled: false
  tmpDirVolume:
    emptyDir:
      medium: Memory

memcached:
  podSecurityContext:
    enabled: false
  containerSecurityContext:
    enabled: false

# The rustfs subchart has no "enabled" toggle for its security contexts. An empty map
# would merge nothing and leave the subchart defaults in place, so the hardcoded UID/GID
# have to be deleted individually for OpenShift to assign its own.
rustfs:
  podSecurityContext:
    fsGroup: null
    runAsUser: null
    runAsGroup: null

redis:
  master:
    podSecurityContext:
      enabled: false
    containerSecurityContext:
      enabled: false
  replica:
    podSecurityContext:
      enabled: false
    containerSecurityContext:
      enabled: false
```

### Deploying with ArgoCD

Due to the way Argo CD syncs Helm charts into the cluster and this chart deploying the initialization job, the default configuration can lead to Sync loops where Argo CD will create an infinite amount of initialization jobs.
To prevent this, add the according annotation to the job to let Argo CD treat it as a Sync Hook.

```yaml
zammadConfig:
  initJob:
    annotations:
      argocd.argoproj.io/hook: Sync
```

## Maintenance Tasks

If you have to run any maintenance commands inside of the Zammad stack, you can do that by
executing them inside of a running Zammad pod:

```sh
kubectl exec zammad-railsserver-NAME_OF_YOUR_RAILSSERVER_POD -c zammad-railsserver -- bash
```

For reindexing the elasticsearch data, e.g. after application updates, there is a slightly more convenient way
available. You can create a job from a cronjob template for it:

```sh
kubectl create job my-reindex-job --from=cronjob/zammad-cronjob-reindex
```

This cronjob never runs by default, but you can change `zammadConfig.cronJob.reindex.suspend`
and `zammadConfig.cronJob.reindex.schedule` if you want to run it periodically.
To use more CPU cores for reindexing, raise `zammadConfig.elasticsearch.reindexWorkers` and the CPU and memory resources
of the container that runs it: `zammadConfig.initContainers.elasticsearch.resources` for the zammad-init job and
`zammadConfig.initContainers.postgresql.resources` for the reindex cronjob.

## Upgrading

**Helm 4 users:** the ECK operator manages fields on the `Elasticsearch` resource (e.g.
`.spec.nodeSets`) via its own field manager, so Helm 4's default Server-Side Apply can make
`helm upgrade` fail with `Apply failed with 1 conflict: conflict with "elastic-operator" ...`. If
you hit this, pass `--force-conflicts` to `helm upgrade` - see
[HIP-0023](https://helm.sh/community/hips/hip-0023/#conflicts-and-forcing).

### From Chart Version 21.x to 22.0.0

The chart's nginx now clears the same request headers as the nginx configuration shipped with Zammad:
`Forwarded`, `X-Forwarded-Scheme` and `X-Forwarded-Ssl` everywhere, `X-Forwarded-User` and `Remote-User`
on `/`. Zammad 7.2.3 and newer answer requests with an outer `Forwarded` header with `500` errors
(`IP spoofing attack?!`), and a client could otherwise choose its own SSO login.

- The request scheme now only comes from `X-Forwarded-Proto`. If TLS ends at a proxy in front of your
  ingress and login fails with "CSRF token verification failed!", set `zammadConfig.nginx.scheme: https`.
- With SSO, pass on the one header your proxy sets, e.g.
  `zammadConfig.nginx.extraHeaders: ['X-Forwarded-User $http_x_forwarded_user']`.
  Make sure that proxy overwrites the header, so clients cannot set it.

### From Chart Version 20.x to 21.0.0

#### Switching to the OCI Registry

Chart versions 21.0.0 and newer are only published to `oci://ghcr.io/zammad/charts/zammad`.
The classic Helm repository at `https://zammad.github.io/zammad-helm` stays at 20.0.2, so `helm upgrade`
from there no longer finds new versions. The chart itself has no breaking changes. Keep your usual flags
and values files and only replace the chart reference:

```console
helm upgrade zammad oci://ghcr.io/zammad/charts/zammad
helm repo remove zammad
```

In GitOps tools, change the chart source as well. For example, in Argo CD set `repoURL: ghcr.io/zammad/charts`
and `chart: zammad`. In Flux, use an `OCIRepository` with `url: oci://ghcr.io/zammad/charts/zammad`
and the chart version as `ref.tag`, or a `HelmRepository` with `type: oci` and `url: oci://ghcr.io/zammad/charts`.

### From Chart Version 19.x to 20.0.0

- The chart's own values are now validated against `values.schema.json`. Values of the wrong type,
  e.g. numbers passed as strings via `--set-string` or quoted in a GitOps tool, now fail with an
  error that names the value. Labels and annotations must be strings.
- `zammadConfig.scheduler.replicas` and `zammadConfig.websocket.replicas` only allow `0` or `1`.
  Higher values are no longer capped to `1`, but rejected.

### From Chart Version 18.x to 19.0.0

#### Minio subchart replaced with RustFS

- The bundled, optional S3 storage provider was migrated from the deprecated `bitnami/minio`
  subchart to [RustFS](https://rustfs.com) and its
  [official chart](https://github.com/rustfs/rustfs/tree/main/helm). MinIO stopped publishing
  community Helm charts and container images, and the MinIO operator repository was archived in
  March 2026, so there is no upstream path there any more. The bitnami chart was already only
  usable through the `bitnamilegacy` image workaround. RustFS is S3-compatible, so Zammad talks to
  it exactly as it did to MinIO.
- **If you used the bundled minio subchart, this is a breaking change that requires a manual,
  one-time data migration** - see [Rustfs data migration](#rustfs-data-migration) below. Read it before you
  upgrade: the old volume is deleted by the upgrade itself unless you protect it first.
- If `zammadConfig.minio.enabled` was `false` (the default), only the value keys below change and
  there is no data to migrate. The same is true if you point Zammad at an external S3 service.
- Please check your values for this subchart, as the structure changed completely:
  - The Zammad-side key `zammadConfig.minio` is now `zammadConfig.rustfs`. `enabled` and
    `externalS3Url` keep their meaning.
  - The subchart values key changed from `minio:` to `rustfs:`. None of the bitnami-specific keys
    (`image`, `clientImage`, `console`, `defaultInitContainers`, `global.security.allowInsecureImages`, …)
    apply any more. Review the new `rustfs.*` block in [values.yaml](./values.yaml).
  - Credentials moved from `minio.auth.rootUser` / `minio.auth.rootPassword` to
    `rustfs.secret.rustfs.access_key` / `rustfs.secret.rustfs.secret_key`. Note that the subchart
    refuses to render with empty or well-known default credentials.
  - `minio.auth.existingSecret` is now `rustfs.secret.existingSecret`, and **the expected keys
    inside that secret changed** from `root-user` / `root-password` to `RUSTFS_ACCESS_KEY` /
    `RUSTFS_SECRET_KEY`.
  - `minio.defaultBuckets` is gone. The rustfs chart cannot provision buckets, so the `zammad-init`
    job now creates it, controlled by `zammadConfig.rustfs.bucketInitialisation` (default `true`)
    and `zammadConfig.rustfs.bucket` (default `zammad`). See
    [Choosing the Storage Provider](#choosing-the-storage-provider).
  - `minio.disableWebUI: true` is now `rustfs.config.rustfs.console_enable: "false"`.
  - The chart sets `rustfs.ingress.enabled: false`, because the subchart would otherwise create an
    ingress for its `example.rustfs.com` default host. Zammad reaches the service cluster-internally.
  - The chart runs the subchart in single-node mode (`rustfs.mode.standalone.enabled: true`,
    `rustfs.replicaCount: 1`) rather than the subchart's own default of a four-pod, erasure-coded
    cluster.
  - The in-cluster service name changed from `{{ .Release.Name }}-minio` to
    `{{ .Release.Name }}-rustfs-svc`; the S3 port stays `9000`. The chart's templates resolve this
    automatically, including when `rustfs.nameOverride` / `rustfs.fullnameOverride` are set.
  - `secrets.s3.*`, for supplying a complete `S3_URL` from an existing secret, is unchanged.
- The new data volume is a fresh, empty `PersistentVolumeClaim` named
  `{{ .Release.Name }}-rustfs-data`. It does not collide with the old minio volume.
- **Behaviour change:** the rustfs chart annotates its PVC with `helm.sh/resource-policy: keep`, so
  the attachment volume now survives uninstalling the release (or setting
  `zammadConfig.rustfs.enabled: false`) and has to be removed manually. The old bitnami PVC was
  deleted in those cases.

#### Rustfs data migration

The upgrade removes the minio subchart. In its default `standalone` mode the bitnami chart created
a plain `PersistentVolumeClaim` named `{{ .Release.Name }}-minio` **without**
`helm.sh/resource-policy: keep`, so Helm deletes that volume - and with it every attachment - as
soon as the subchart is gone. Step 2 below prevents this and must not be skipped. (If you ran the
subchart in `distributed` mode, the volumes are StatefulSet `volumeClaimTemplates` named
`data-{{ .Release.Name }}-minio-N`, which Kubernetes never deletes automatically.)

RustFS reads MinIO's on-disk layout and migrates its metadata on first start, so the attachments
can be moved as a plain file copy between the two volumes - no S3 client, no data leaving the
cluster, and the database is not involved (Zammad keys each attachment by its SHA256 checksum and
references that, not the storage backend). Adjust namespace and release name to your setup:

```bash
# 1. Stop Zammad so there are no more writes to the attachment store. If you have enabled the
#    reindex cronjob, suspend it as well - it runs Zammad too and would otherwise still write.
kubectl scale -n <namespace> deploy -l app.kubernetes.io/name=zammad --replicas=0
kubectl patch -n <namespace> -p '{"spec":{"suspend":true}}' \
  "$(kubectl get cronjob -n <namespace> -l app.kubernetes.io/component=zammad-cronjob-reindex -o name)"

# 2. Protect the old minio volume, so that the upgrade in step 3 leaves it behind instead of
#    deleting it. It then serves as your rollback safety net and as the source for the copy.
kubectl annotate pvc -n <namespace> <release_name>-minio helm.sh/resource-policy=keep

# 3. Phase one: upgrade with everything scaled to zero. This creates the new, empty rustfs
#    volume without ever starting rustfs on it, so it stays pristine for the copy below.
#    The init job is disabled here because the bucket comes with the copied data.
#    Port my-values.yaml to the new keys first (zammadConfig.minio -> zammadConfig.rustfs
#    with enabled: true, minio: -> rustfs:, see above) - the chart deliberately refuses to
#    render while the removed keys are still present.
#    Set rustfs.storageclass.dataStorageSize in my-values.yaml to at least the size of the
#    old volume beforehand - it defaults to 10Gi and a PVC cannot be shrunk again later.
#    Read the old size with:
#      kubectl get pvc -n <namespace> <release_name>-minio \
#        -o jsonpath='{.spec.resources.requests.storage}'
helm upgrade <release_name> . -n <namespace> -f my-values.yaml \
  --set zammadConfig.initJob.enabled=false \
  --set zammadConfig.nginx.replicas=0 \
  --set zammadConfig.railsserver.replicas=0 \
  --set zammadConfig.scheduler.replicas=0 \
  --set zammadConfig.websocket.replicas=0 \
  --set zammadConfig.cronJob.reindex.suspend=true \
  --set rustfs.replicaCount=0

# 4. Copy the data directory from the old volume to the new one. The rm drops the lost+found
#    that ext4-backed volumes carry, which would otherwise show up as a stray bucket. The
#    chown matches the subchart's default runAsUser/fsGroup; adjust it if you changed those.
kubectl apply -n <namespace> -f - <<'EOF'
apiVersion: batch/v1
kind: Job
metadata:
  name: minio-to-rustfs
spec:
  backoffLimit: 0
  template:
    spec:
      restartPolicy: Never
      securityContext:
        runAsUser: 0
      containers:
        - name: copy
          image: alpine:3
          command: ["sh", "-ec", "cp -a /src/. /dst/ && rm -rf /dst/lost+found && chown -R 10001:10001 /dst && du -sh /dst"]
          volumeMounts:
            - { name: src, mountPath: /src }
            - { name: dst, mountPath: /dst }
      volumes:
        - name: src
          persistentVolumeClaim: { claimName: <release_name>-minio }
        - name: dst
          persistentVolumeClaim: { claimName: <release_name>-rustfs-data }
EOF
kubectl wait -n <namespace> --for=condition=complete --timeout=2h job/minio-to-rustfs
kubectl logs -n <namespace> job/minio-to-rustfs

# 5. Phase two: upgrade with your regular values. RustFS starts on the copied directory and
#    migrates MinIO's metadata into its own; the init job finds the bucket already present.
#    Note that --reset-values drops the --set values from step 3. If you prefer to keep other
#    values set on the command line, omit it and reset the keys from step 3 manually.
helm upgrade <release_name> . -n <namespace> -f my-values.yaml --reset-values

# 6. Once you have verified that attachments open correctly in Zammad, clean up at your
#    convenience. Until then the old volume is untouched and you can roll back to it.
kubectl delete job -n <namespace> minio-to-rustfs
kubectl delete pvc -n <namespace> <release_name>-minio
```

The Job runs as root for the `chown`, which a namespace enforcing the `restricted`
[Pod Security Standard](https://kubernetes.io/docs/concepts/security/pod-security-standards/) (or
OpenShift's default SCC) rejects. There, drop `securityContext.runAsUser` and the `chown`, and
leave `fsGroup` unset: the SCC assigns it per namespace and the kubelet relabels the volume to the
same GID the rustfs pod gets. Only pin a `fsGroup` if you assign the IDs yourself.

The copy Job mounts both volumes at once, so they have to be attachable to the same node - with
`ReadWriteOnce` volumes bound to different nodes or zones the Job will not schedule. In that case
copy at the object level instead, which needs no shared node but does need somewhere to park the
data: before step 3, port-forward `svc/<release_name>-minio` and pull the bucket into a local
directory with any S3 client (`rclone sync old:zammad ./attachments`); after step 3, port-forward
`svc/<release_name>-rustfs-svc` and push it back (`rclone sync ./attachments new:zammad`). Skip
step 4, and in step 3 drop both `--set zammadConfig.initJob.enabled=false` and
`--set rustfs.replicaCount=0`, so that rustfs runs and the init job creates the bucket for you.

Zammad could in principle also move the attachments itself, via the `Database` or `File` provider
and back - see [How to migrate from `File` to `S3` storage](#how-to-migrate-from-file-to-s3-storage)
for the `Store::File.move` mechanism. That needs no external tooling, but the intermediate provider
has to hold every attachment, so it is rarely practical for an installation that is already on S3.

### From Chart Version 17.x to 18.0.0

#### Elasticsearch subchart migrated to the ECK operator

- The bundled Elasticsearch was migrated from the `bitnami/elasticsearch` subchart to the
  official [`eck-elasticsearch`](https://artifacthub.io/packages/helm/elastic/eck-elasticsearch)
  chart, which is managed by the [ECK operator](https://www.elastic.co/guide/en/cloud-on-k8s/current/k8s-overview.html).
  This is the deployment method officially supported by Elastic.
- **The ECK operator (and its CRDs), version 3.5.0+, must now be installed in the cluster**
  before upgrading when `zammadConfig.elasticsearch.enabled` is `true` (the default). See
  [Prerequisites](#prerequisites).
- The `elasticsearch.*` values changed completely. The previous bitnami values (`master`, `data`,
  `ingest`, `coordinating`, `sysctlImage`, `image`, `global.security.allowInsecureImages`, …) no
  longer apply. Review the new `elasticsearch.*` block in `values.yaml` (`nodeSets`, `http`, …).
- Authentication is now mandatory: ECK creates a superuser `elastic` and stores its password in
  an auto-generated secret, typically named `{{ .Release.Name }}-es-es-elastic-user` (depending
  on your release name, see below). The chart wires this up automatically, so
  `secrets.elasticsearch.*` is only relevant for an **external** Elasticsearch now. Since TLS on
  the HTTP layer is disabled by default (see below), this password still crosses the cluster
  network in plaintext on every request, same as the previous unauthenticated setup did for all
  traffic — authentication alone does not protect it in transit.
- The in-cluster service name changed from `{{ .Release.Name }}-elasticsearch` to typically
  `{{ .Release.Name }}-es-es-http`. The exact name depends on your release name: if it already
  contains `es` as a substring (e.g. `zammad-helpdesk`), it's used as-is instead of getting `-es`
  appended, giving `{{ .Release.Name }}-es-http` instead. Either way, the chart's own templates
  resolve this automatically. Note that ECK caps the Elasticsearch resource name itself at 36
  characters; the chart fails fast with a clear error at template/install time if your release
  name is too long to fit.
- TLS on the HTTP layer is disabled by default (`elasticsearch.http.tls.selfSignedCertificate.disabled: true`)
  to keep the plain-`http` connection behaviour. Enabling the operator-managed self-signed
  certificate (`selfSignedCertificate.disabled: false` with `zammadConfig.elasticsearch.schema: https`)
  is **not supported yet**: Zammad verifies TLS certificates by default and the chart does not mount
  the ECK-generated CA certificate into the Zammad pods, so the zammad-init job will fail on
  certificate verification. Leave TLS disabled unless you terminate it yourself and configure
  Zammad's Elasticsearch client accordingly.
- The StatefulSet and its `PersistentVolumeClaim`s are recreated under new names. As the search
  index can be rebuilt from PostgreSQL, the recommended path is to delete the old bitnami
  Elasticsearch PVCs and let the index be recreated. This usually happens automatically when the
  zammad-init job runs and finds no index to be available.
- **Behaviour change:** the ECK operator's default `volumeClaimDeletePolicy` is
  `DeleteOnScaledownAndClusterDeletion`, so uninstalling the release (or setting
  `zammadConfig.elasticsearch.enabled: false`) now also deletes the Elasticsearch data volume.
  The old bitnami PVCs were left behind on uninstall. This is harmless in practice since the
  index rebuilds from PostgreSQL, but if you rely on the volume surviving an uninstall, set
  `elasticsearch.volumeClaimDeletePolicy: DeleteOnScaledownOnly` explicitly.

#### Faster volume permission fixing

- `securityContext.fsGroupChangePolicy` now defaults to `OnRootMismatch` instead of `Always`. This
  avoids a lengthy startup delay on volumes with a large number of files, since Kubernetes only
  recurses into a volume to fix ownership if the volume's root directory doesn't already have the
  expected group ownership. This is safe for existing volumes (their ownership was already set by
  a previous `Always` run) and only changes behaviour on future pod restarts. If you rely on the
  old, more thorough behaviour, set `securityContext.fsGroupChangePolicy: Always` explicitly.

#### `initJob.randomName` removed

- The `zammadConfig.initJob.randomName` setting was removed. The init Job name is now always
  suffixed with the Helm release revision, which is what `randomName: true` (the default) already
  did in practice.
- If you had set `randomName: false`, e.g. for the Argo CD workaround described in
  [Deploying with ArgoCD](#deploying-with-argocd), remove that line - it is now a no-op. Argo CD
  and other tools that render the chart statically (also `helm template`, `helm diff`) always see
  revision `1`, so the job name is stable there regardless. It's the Sync Hook annotation that
  actually prevents the sync loop, and that is unaffected by this change.
- On upgrade, installs that previously had `randomName: false` will see their init Job renamed once
  (`<fullname>-init` to `<fullname>-init-<revision>`); this is a harmless one-time replacement.

### From Chart Version 16.x to 17.0.0

- The bitnami PostgreSQL subchart was replaced with [cloudpirates-postgres/postgres](https://artifacthub.io/packages/helm/cloudpirates-postgres/postgres).
  This is a **breaking change that requires a manual, one-time data migration**, because the new subchart uses a
  different data directory layout and image, and PostgreSQL data volumes cannot be reused across these charts as-is.
- Please check your values for this subchart, as the structure changed:
  - The values key for the subchart changed from `postgresql:` to `postgres:` (the subchart is now used under its
    own name, consistent with the `redis` and `memcached` subcharts).
  - The bitnami-specific keys (`auth.postgresPassword`, `auth.replicationUsername`, `auth.replicationPassword`,
    the `bitnamilegacy` image workarounds and `global.security.allowInsecureImages`) are gone.
  - The password is now configured via `postgres.auth.password` (or an existing secret referenced by
    `postgres.auth.existingSecret` with the key from `postgres.auth.secretKeys.adminPasswordKey`, default `postgres-password`).
  - The DB service is now named `{{ .Release.Name }}-postgres` (was `{{ .Release.Name }}-postgresql`). This is handled
    internally; `zammadConfig.postgresql.*` (host/port/user/pass/db) is unchanged.
  - Because the new resources use a different name, the new `PersistentVolumeClaim`
    (`data-{{ .Release.Name }}-postgres-0`) does **not** collide with the old one
    (`data-{{ .Release.Name }}-postgresql-0`). The old volume is left untouched during the upgrade and serves as a
    rollback safety net; you can remove it once the migration is verified.
  - The new subchart uses the official `postgres` image and defaults to the latest major version. Since the migration
    below is a logical dump/restore, the database is upgraded to that major version in the process.
  - Zammad's database user is now a PostgreSQL superuser. With the bitnami subchart, `zammad` was an unprivileged
    user owning the database, next to a separate `postgres` superuser. The new subchart creates the user from
    `postgres.auth.username` via the official image's `POSTGRES_USER`, which is always a superuser. Zammad does not
    need those privileges. As the PostgreSQL instance is dedicated to Zammad the impact is limited, but if you
    prefer to keep the application unprivileged, the subchart's `customUser` block can be used instead - see the
    commented example in [values.yaml](./values.yaml).
- New settings (not breaking, needed by the migration procedure below):
  - `zammadConfig.initJob.enabled` can be set to `false` to temporarily skip the initialisation job.
  - `zammadConfig.scheduler.replicas` and `zammadConfig.websocket.replicas` can now be set to `0` to disable
    those components. They may only run once per cluster, so any value above `1` is capped to `1`.

#### PostgreSQL data migration

The new subchart provisions a fresh, empty PostgreSQL cluster on its own volume, so the migration is a
non-destructive logical dump/restore (adjust namespace, release name and credentials to your setup).

```bash
# 1. Stop Zammad so there are no more writes to the database. If you have enabled the reindex
#    cronjob, suspend it as well - it runs Zammad too and would otherwise still access the database.
kubectl scale -n <namespace> deploy -l app.kubernetes.io/name=zammad --replicas=0
kubectl patch -n <namespace> -p '{"spec":{"suspend":true}}' \
  "$(kubectl get cronjob -n <namespace> -l app.kubernetes.io/component=zammad-cronjob-reindex -o name)"

# 2. Take a logical backup from the still-running OLD (bitnami) instance
kubectl exec -n <namespace> <release_name>-postgresql-0 -- \
  env PGPASSWORD=<password> pg_dump -Fc -U zammad -d zammad_production \
  > zammad_production.dump

# 3. Phase one: upgrade with the init job and all Zammad components disabled, so that only the new,
#    empty PostgreSQL cluster comes up (on its own PVC data-<release>-postgres-0; the old PVC is
#    left untouched). Nothing may connect to the new database before the restore.
#    Otherwise, a new database would be set up and the Rails bookkeeping tables
#    `schema_migrations`, `ar_internal_metadata` would be created by the Pods.
helm upgrade <release_name> . -n <namespace> -f my-values.yaml \
  --set zammadConfig.initJob.enabled=false \
  --set zammadConfig.nginx.replicas=0 \
  --set zammadConfig.railsserver.replicas=0 \
  --set zammadConfig.scheduler.replicas=0 \
  --set zammadConfig.websocket.replicas=0 \
  --set zammadConfig.cronJob.reindex.suspend=true

# 4. Restore the dump into the new database. It is streamed via stdin, so it needs no disk space
#    inside the container. Use 'kubectl exec -i' without '-t': a TTY would corrupt the binary
#    stream. '--clean --if-exists' makes the step repeatable if a previous attempt failed.
kubectl exec -i -n <namespace> <release_name>-postgres-0 -- \
  env PGPASSWORD=<password> pg_restore -U zammad -d zammad_production --no-owner --clean --if-exists \
  < zammad_production.dump

# 5. Phase two: upgrade again with your regular values. The init job now finds the restored
#    data and only migrates it, and Zammad is scaled back up to your configured replicas (via --reset-values).
#    Note that this will delete all other values specified via --set before, which are not present in the values file.
#    To avoid this behaviour, you can omit --reset-values and specify the keys from above manually.
helm upgrade <release_name> . -n <namespace> -f my-values.yaml --reset-values

# 6. Once you have verified everything works, clean up the old volume at your convenience
kubectl delete pvc -n <namespace> data-<release_name>-postgresql-0
```

### From Chart Version 15.x to 16.0.0

- The bitnami memcached subchart was replaced with [cloudpirates-memcached/memcached](https://artifacthub.io/packages/helm/cloudpirates-memcached/memcached).
  This should be a seamless update.
- The bitnami redis subchart was replaced with [cloudpirates-redis/redis](https://artifacthub.io/packages/helm/cloudpirates-redis/redis).
  - Please check your values for this subchart, as there have been minor changes here (resources configuration is now on the top level rather than in `master`).
  - The name of the primary redis service has changed from `{{ .Release.Name }}-redis-master` to `{{ .Release.Name }}-redis`.
  - The new subchart creates its own `PersistentVolumeClaim`. As Zammad does not store permantent data in Redis, there is no data migration required here. Feel free to clean up the unused `PersistentVolumeClaim` from the previous subchart at your convenience (it has `master` in its name, e.g. `redis-data-zammad-redis-master-0`).

### From Chart Version 14.x to 15.0.0

- The selector matchLabels of all deployments changed which are unfortunately immutable. This means each deployment needs to
  be deleted before upgrading the helm chart. To preserve high availability the `cascade=orphan` option can be used
  (e.g. `kubectl/oc delete deployment --selector app.kubernetes.io/name=zammad --cascade=orphan`).

### From Chart Version 13.x to 14.0.0

- The default value of `zammadConfig.elasticsearch.reindex` changed from `true` to `false`. This means that
  with the default value, the chart will no longer reindex the elasticsearch content after every single
  update (which caused search results to be incomplete until the reindexing finished).
- With the new default value of `false`, the chart will still create an index on installation (if no index is present).

### From Chart Version 12.x to 13.0.0

- All subcharts received updates to the latest major version. Please refer to their upgrading instructions.
- Note especially [bitnami/postgresql#upgrading](https://artifacthub.io/packages/helm/bitnami/postgresql#upgrading),
  because the upgrade to PostgeSQL 17 will require manual action to upgrade the cluster data to the new version.

### From Chart Version 11.x to 12.0.0

#### The Previous `StatefulSet` Was Split up into `Deployments`

- `replicas` can be set independently now for `zammad-nginx` and `zammad-railsserver`, allowing free scaling and HA setup for these.
  - For `zammad-scheduler` and `zammad-websocket`, `replicas` is fixed to `1` as they may only run once in the cluster.
- The `initContainers` moved to a new `zammad-init` `Job` now which will be run on every `helm upgrade`. This reduces startup time greatly.
- The nginx `Service` was renamed from `zammad` to `zammad-nginx`.
- The previous `Values.sidecars` setting does not exist any more. Instead, you need to specify sidecars now on a per deployment basis, e.g. `Values.zammadConfig.scheduler.sidecars`.

#### Storage Requirements Changed

- If you use the default `DB` or the new `S3` storage backend for file storage, you don't need to do anything.
- If you use the `File` storage backend instead, Zammad now requires a `ReadWriteMany` volume for `storage/` that is shared in the cluster.
  - If you already had one via `persistence.existingClaim` before, you need to ensure it has `ReadWriteMany` access to be mountable across nodes and provide it via `zammadConfig.storageVolume.existingClaim`.
  - If you used the default `PersistentVolumeClaim` of the `StatefulSet`, you need to take manual action:
    - You can either migrate to `S3` storage **before upgrading** to the new major version as described above in [Configuration](#how-to-migrate-from-file-to-s3-storage).
    - Or you can provide a `zammadConfig.storageVolume.existingClaim` with `ReadWriteMany` permission and migrate your existing data to it from the old `StatefulSet`.

### From Chart Version 10.x to 11.0.0

- Minimum Zammad version is now 6.3.0, where there is no `var/` folder any more, and the related
  mount points have been removed.
- The handling of the Autowizard secret was simplified. It is no longer processed by an init container,
  but instead mounted directly into the Zammad container. Therefore the secret must contain the actual
  raw JSON value, and not the base64 encoded JSON. So if you use an existing Autowizard secret,
  you will need to change it to contain the raw value now.
- There is a new `.Values.zammadConfig.postgresql.options` setting that can be used to specify additional
  settings for the database connection. By default it specifies Zammad's default Rails DB pool size of 50.
  For large installations you may need to increase this value.

### From Chart Version 9.x to 10.0.0

- all containers uses `readOnlyRootFilesystem: true` again
- volumePermissions init container config has been moved to initContainers section
  - if you used it before you have to adapt your config
  - it's also enabled by default now to workaround rails world writable tmp dir issues
  - if you don't like to use it you might want to set tmpDirVolume.emptyDir.medium to "Memory" instead

### From Chart Version 8.x to 9.0.0

- Zammads PVC changed to only hold contents of /opt/zammad/var & /opt/zammad/storage instead of the whole Zammad content
  - A new PVC `zammad-var` is created for this
  - the old zammad PVC is kept in case you need data from there (for example if you used filesystem storage)
    - you need to copy the contents of /opt/zammad/storage to the new volume manually or restore them from a backup
  - to update Zammad you have to delete the Zammad StatefulSet first, as the immutable volume config is changed
    - `kubectl delete sts zammad`
    - `helm upgrade zammad zammad/zammad`
- Zammads initContainer rsync step is no longer needed and therfore removed
- DB config is now done via `DATABASE_URL` env var instead of creating a database.yml in the config directory
- Zammads pod securityContext has a new default setting for "seccompProfile:" with value "type: RuntimeDefault"
- Docker registry changed to ghcr.io/zammad/zammad
- auto_wizard.json is placed into /opt/zammad/var directory now
- All subcharts have been updated

### From Chart Version 7.x to 8.0.0

SecurityContexts of pod and containers are configurable now.
We also changed the default securitycontexts, to be a bit more restrictive, therefore the major version upgrade of the chart.

On the pod level the following defaults are used:

```yaml
securityContext:
  fsGroup: 1000
  runAsUser: 1000
  runAsNonRoot: true
  runAsGroup: 1000
```

On the containerlevel the following settings are used fo all zammad containers now (some init containers may run as root though):

```yaml
securityContext:
  allowPrivilegeEscalation: false
  capabilities:
    drop:
      - ALL
  readOnlyRootFilesystem: true
  privileged: false
```

As `readOnlyRootFilesystem: true` is set for all Zammad containers, the Nginx container writes its PID and tmp files to `/tmp`.
The `/tmp` volume can be configured via `zammadConfig.tmpDirVolume`. Currently a 100Mi emptyDir is used for that.
The nginx config in `/etc/nginx/nginx.conf` is now populated from the Nginx configmap too.

If the volumpermissions initContainer is used, the username and group are taken from the `securityContext.runAsUser` & `securityContext.runAsGroup` variables.

The rsync command in the zammad-init container has been changed to not use "--no-perms --no-owner --no-group --omit-dir-times".
If you wan't the old behaviout use the new `.Values.zammadConfig.initContainers.zammad.extraRsyncParams` variable, to add these options again.

We've also set the Elasticsearch master heapsize to "512m" by default.

### From Chart Version 6.x to 7.0.0

- Bitnami Elasticsearch chart is used now as Elastic does not support the old chart anymore in favour of ECK operator
  - reindexing of all data is needed so get sure "zammadConfig.elasticsearch.reindex" is set to "true"
- Memchached was updated from 6.0.16 to 6.3.0
- PostgreSQL chart was updated from 10.16.2 to 12.1.0
  - this includes major version change of Postgres DB version too
  - backup / restore is needed to update
  - postgres password settings were changed
  - see also upgrading [PostgreSQL upgrading notes](https://github.com/bitnami/charts/tree/main/bitnami/postgresql#upgrading)
- Redis chart is updated from 16.8.7 to 17.3.7
  - see [Redis upgrading notes](https://github.com/bitnami/charts/tree/main/bitnami/redis#to-1700)
- Zammad
  - Pod Security Policy settings were removed as these are [deprecated in Kubernetes 1.25](https://kubernetes.io/docs/concepts/security/pod-security-policy/)
  - Docker image tag is used from Chart.yaml "appVersion" field by default
  - Replicas can be configured (needs ReadWriteMany volume if replica > 1!)
  - livenessProbes and readinessProbe have been adjusted to not be the same
  - config values has been removed from chart readme as it's easier to maintain them at a single place

### From Chart Version 6.0.4 to 6.0.x

- minimum helm version now is 3.2.0+
- minimum Kubernetes version now is 1.19+

### From Chart Version 5.x to 6.x

- `envConfig` variable was replaced with `zammadConfig`
- `nginx`, `rails`, `scheduler`, `websocket` and `zammad` vars has been merged into `zammadConfig`
- Chart dependency vars have changed (reside in `zammadConfig` too now), so if you've disabled any of them you have to adapt to the new values from the Chart.yaml
- `extraEnv` var is a list now

### From Chart Version 4.x to 5.x

- health checks have been extended from boolean flags that simply toggle readinessProbes and livenessProbes on the containers to templated
  ones: .zammad.{nginx,rails,websocket}.readinessProbe and .zammad.{nginx,rails,websocket}.livenessProbe have been removed in favor of livenessProbe/readinessProbe
  templates at .{nginx,railsserver,websocket}. You can customize those directly in your overriding values.yaml.
- resource constraints have been grouped under .{nginx,railsserver,websocket} from above. They are disabled by default (same as prior versions), but in your overrides, make sure
  to reflect those changes.

### From Chart Version 1.x

This has changed:

- requirement chart condition variable name was changed
- the labels have changed
- the persistent volume claim was changed to persistent volume claim template
  - import your filebackup here
- all requirement charts has been updated to the latest versions
  - Elasticsearch
    - docker image was changed to `elastic/elasticsearch`
    - version was raised from 5.6 to 7.6
    - reindexing will be done automatically
  - Postgres
    - `bitnami/postgresql` chart is used instead of `stable/postgresql`
    - version was raised from 10.6.0 to 11.7.0
    - there is no automated upgrade path
    - you have to import a backup manually
  - Memcached
    - `bitnami/memcached` chart is used instead of `stable/memcached`
    - version was raised from 1.5.6 to 1.5.22
    - nothing to do here

**Before the update backup Zammad files and make a PostgreSQL backup, as you will need these backups later!**

- If your helm release was named "zammad" and also installed in the namespace "zammad" like:

```bash
helm upgrade --install zammad zammad/zammad --namespace=zammad --version=1.2.1
```

- Do the upgrade like this:

```bash
helm delete --purge zammad
kubectl -n zammad delete pvc data-zammad-postgresql-0 data-zammad-elasticsearch-data-0 data-zammad-elasticsearch-master-0
helm upgrade --install zammad zammad/zammad --namespace=zammad --version=2.0.3
```

- Import your file and SQL backups inside the Zammad & PostgreSQL containers

### From Zammad 2.6.x to 3.x

As Helm 2.x was deprecated Helm 3.x is needed now to install Zammad Helm chart.
Minimum Kubernetes version is 1.16.x now.

As PostgreSQL dependency Helm chart was updated, have a look at the upgrading instructions to 9.0.0 and 10.0.0 of the PostgreSQL chart:

- <https://artifacthub.io/packages/helm/bitnami/postgresql#to-9-0-0>
- <https://artifacthub.io/packages/helm/bitnami/postgresql#to-10-0-0>

### From Zammad 3.5.x to 4.x

Ingress config has been updated to the default of charts created with Helm 3.6.0 so you might need to adapt your ingress config.
